import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_basics/exapmle2.dart';

class StateFullExample extends StatefulWidget {
  const StateFullExample({super.key});

  @override
  State<StateFullExample> createState() => _StateFullExampleState();
}

class _StateFullExampleState extends State<StateFullExample> {
  @override
  void initState() {
    log('initState called'); // This will log when the widget is initialized
    super.initState();
  }

  @override
  void didChangeDependencies() {
    log('didChangeDependencies called'); // This will log when the dependencies change
    super.didChangeDependencies();
  }

  @override
  void didUpdateWidget(covariant StateFullExample oldWidget) {
    log('didUpdateWidget called'); // This will log when the widget is updated
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    log('build called');

    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Column(
              children: [
                Row(
                  children: [
                    Text('Stateful Widget Example'),
                  ],
                ),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Column(
                              children: [
                                Text('Stateful Widget Example'),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Text('Stateful Widget Example'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => const ExampleStatless()));
              },
              child: Text('Go to Stateless Widget Example')),
          Text('Stateful Widget Example'),
          Center(
              child: Padding(
            padding: EdgeInsets.all(8.0),
            child: Center(child: Text('Stateful Widget Example')),
          )),
          Row(
            children: [
              Text('Stateful Widget Example'),
            ],
          )
        ],
      ),
    );
  }

  @override
  void deactivate() {
    log('deactivate called'); // This will log when the widget is removed from the tree
    super.deactivate();
  }

  @override
  void dispose() {
    log('dispose called'); // This will log when the widget is disposed
    super.dispose();
  }
}
