import 'package:flutter/material.dart';

class ExampleStatless extends StatelessWidget {
  const ExampleStatless({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('this is a statless screen'),
      ),
    );
  }
}
